import java.util.*;
import java.sql.*;

public class EmpDmo {
    public static Connection getConnection() {
        Connection con=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");  // ✅ fixed
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");  // ✅ fixed
        } catch(Exception e) {System.out.println(e);}
        return con;
    }
    public static int save(Emp e) throws SQLException
    {
        int status=0;
        try{
            Connection con=EmpDmo.getConnection();
            PreparedStatement ps=con.prepareStatement("insert into servletcrud values (?,?,?,?,?)");
            ps.setInt(1,e.getId());
            ps.setString(2,e.getName());
            ps.setString(3,e.getPassword());
            ps.setString(4,e.getEmail());
            ps.setString(5,e.getCountry());
            
            status=ps.executeUpdate();
            
            con.close();
        } catch(Exception ex) {ex.printStackTrace();}
        
        return status;
    }
    public static int update(Emp e){
        int status=0;
        try{
            Connection con=EmpDmo.getConnection();
            PreparedStatement ps=con.prepareStatement("update servletcrud set Name=?,password=?,Email=?,Country=? where ID=?");  // ✅ fixed
            ps.setString(1,e.getName());
            ps.setString(2,e.getPassword());
            ps.setString(3,e.getEmail());
            ps.setString(4,e.getCountry());
            ps.setInt(5,e.getId());
            
            status=ps.executeUpdate();
            
            con.close();
        }catch(Exception ex) {ex.printStackTrace();}
        return status;
    }
    public static int delete(int id)
    {
        int status=0;
        try{
            Connection con=EmpDmo.getConnection();
            PreparedStatement ps=con.prepareStatement("delete from servletcrud where ID=?");
            ps.setInt(1,id);
            status=ps.executeUpdate();
            
            con.close();
        }catch(Exception e) {e.printStackTrace();}
        return status;
    }
    public static Emp getEmployeeById(int id)
    {
        Emp e =new Emp();
        
        try{
            Connection con=EmpDmo.getConnection();
            PreparedStatement ps=con.prepareStatement("select * from servletcrud where ID=? ");
            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                e.setId(rs.getInt(1));
                e.setName(rs.getString(2));
                e.setPassword(rs.getString(3));
                e.setEmail(rs.getString(4));
                e.setCountry(rs.getString(5));
            }
            con.close();
        }catch(Exception ex) {ex.printStackTrace();}
        
        return e;
    }
    public static List<Emp> getAllEmployee()
    {
        List<Emp> list = new ArrayList<Emp>();
        try{
            Connection con=EmpDmo.getConnection();
            PreparedStatement ps=con.prepareStatement("select * from servletcrud");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Emp e=new Emp();
                e.setId(rs.getInt(1));
                e.setName(rs.getString(2));
                e.setPassword(rs.getString(3));
                e.setEmail(rs.getString(4));
                e.setCountry(rs.getString(5));
                list.add(e);
            }
            con.close();
        }catch(Exception e) {e.printStackTrace();}
        
        return list;
    }
}
