/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EditServlet2 extends HttpServlet{
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
            response.setContentType("text/html");
    PrintWriter out=response.getWriter();
    
    String sid=request.getParameter("eid");
    int id=Integer.parseInt(sid);
    String name=request.getParameter("name");
    String password=request.getParameter("password");
    String email=request.getParameter("email");
    String country=request.getParameter("country");
    
    Emp e =new Emp();
    e.setId(id);
    e.setName(name);
    e.setPassword(password);
    e.setEmail(email);
    e.setCountry(country);
    
    int status=EmpDmo.update(e);
    
    if(status>0){
    response.sendRedirect("ViewServlet");
}
    else{
    out.println("Sorry! unable to update record");
}
}
}
